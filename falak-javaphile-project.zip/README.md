# FALAK. — JAVAPHILE COLLECTION

A cinematic, mobile-first birthday microsite built with React, Vite, Tailwind CSS v4, Framer Motion and Lucide React.

## Requirements
- Node.js 20.19+ or 22.12+
- npm (or pnpm)

## Run locally
```bash
npm install
npm run dev
```
Open the local URL printed by Vite.

## Production build
```bash
npm run build
npm run preview
```
The production-ready static site is generated in `dist/`.

## Deploy
Deploy the project to any static hosting provider (Vercel, Netlify, Cloudflare Pages, or an Nginx/VPS static root).
- Build command: `npm run build`
- Output directory: `dist`

## Customisation
- Birthday text and interactions: `src/App.jsx`
- Visual system, responsive styles, motion and reduced-motion rules: `src/index.css`
- Site metadata and font imports: `index.html`
- Change the editable closing signature directly in the final section, or leave the on-page input editable for the creator.

## Notes
- Frontend only; no backend, login or data collection.
- Ambient audio is an optional, user-initiated synthesized tone. It never autoplays.
- Coffee option is spelled **Cranbury**, exactly as supplied. No ingredients or flavour notes are assumed.
- The night drive is a visual simulation only.
- External Google Fonts are progressive enhancement; serif/system fallbacks are included.
- The visual drink, garden, pizza and cake illustrations are CSS-built, so the experience has no dependency on remote stock images.
- All interactive elements are keyboard-focusable and the stylesheet respects `prefers-reduced-motion`.
