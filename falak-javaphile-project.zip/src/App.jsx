import { useEffect, useRef, useState } from 'react'
import { AnimatePresence, motion, useReducedMotion } from 'framer-motion'
import {
  ArrowDown, ArrowUpRight, AudioLines, Check, ChevronDown, Coffee,
  Flower2, Heart, Menu, Music2, Pause, Play, RotateCcw, Sparkles,
  Volume2, VolumeX, X
} from 'lucide-react'

const wishes = [
  'May life always give you reasons to bloom.',
  'May your next chapter be even more beautiful than the last.',
  'May you never lose the curiosity that makes you different.',
  'Keep growing. Keep glowing. Keep being you.',
]
const coffeeMessages = [
  'Running on caffeine and extraordinary energy.',
  'Some people need a morning routine. Some just need coffee.',
  "Coffee isn't a habit. It's a personality at this point.",
]
const driveLines = [
  'Some journeys become memorable because of the company.',
  'Good conversations, empty roads and a little music.',
  "May life take you to places you've always wanted to see.",
]
const quiz = [
  { q: 'Choose your perfect evening.', a: ['Iced latte and peace.', 'Long drive.', 'Pizza and a movie.'] },
  { q: "What's your survival fuel?", a: ['Cranbury.', 'Iced Latte.', 'Both. Obviously.'] },
  { q: 'Choose your aesthetic.', a: ['Lavender dreams.', 'Midnight purple.', 'Something extraordinary.'] },
]
const quizResults = [
  'THE SOFT-LIFE EXPLORER — a little caffeine, a little calm, and a universe of curiosity.',
  'THE MIDNIGHT NOMAD — windows down, mind wide open, ordinary nowhere in sight.',
  'THE MAIN-CHARACTER MENU — good food, good energy, and absolutely no boring options.',
]

function Eyebrow({ children }) { return <div className="eyebrow"><span />{children}</div> }
function SectionHead({ index, eyebrow, title, subtitle }) {
  return <div className="section-head">
    <Eyebrow>{index} / {eyebrow}</Eyebrow>
    <h2>{title}</h2>
    {subtitle && <p>{subtitle}</p>}
  </div>
}
function Reveal({ children, className = '', delay = 0 }) {
  const reduce = useReducedMotion()
  return <motion.div className={className} initial={reduce ? false : { opacity: 0, y: 28 }}
    whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true, amount: 0.16 }}
    transition={{ duration: reduce ? 0 : .8, delay, ease: [.22, 1, .36, 1] }}>{children}</motion.div>
}

function App() {
  const [entered, setEntered] = useState(false)
  const [coffeeChoice, setCoffeeChoice] = useState('')
  const [coffeeMessage, setCoffeeMessage] = useState('')
  const [gardenWish, setGardenWish] = useState('')
  const [driving, setDriving] = useState(false)
  const [driveLine, setDriveLine] = useState(0)
  const [pizzaChoice, setPizzaChoice] = useState('')
  const [pizzaReply, setPizzaReply] = useState('')
  const [quizStep, setQuizStep] = useState(0)
  const [answers, setAnswers] = useState([])
  const [quizDone, setQuizDone] = useState(false)
  const [secretOpen, setSecretOpen] = useState(false)
  const [signature, setSignature] = useState('A little creativity & a lot of thought.')
  const [musicOn, setMusicOn] = useState(false)
  const [menuOpen, setMenuOpen] = useState(false)
  const audioRef = useRef(null)
  const oscillatorsRef = useRef([])
  const reduce = useReducedMotion()

  useEffect(() => {
    if (!driving || reduce) return
    const timer = window.setInterval(() => setDriveLine(v => (v + 1) % driveLines.length), 3600)
    return () => window.clearInterval(timer)
  }, [driving, reduce])

  useEffect(() => () => {
    oscillatorsRef.current.forEach(o => { try { o.stop() } catch {} })
    if (audioRef.current) audioRef.current.close()
  }, [])

  const toggleMusic = async () => {
    if (musicOn) {
      oscillatorsRef.current.forEach(o => { try { o.stop() } catch {} })
      oscillatorsRef.current = []
      if (audioRef.current) await audioRef.current.close()
      audioRef.current = null
      setMusicOn(false)
      return
    }
    const AudioContext = window.AudioContext || window.webkitAudioContext
    if (!AudioContext) return
    const ctx = new AudioContext()
    audioRef.current = ctx
    await ctx.resume()
    const master = ctx.createGain()
    master.gain.value = 0.035
    master.connect(ctx.destination)
    ;[110, 164.81, 220].forEach((freq, i) => {
      const osc = ctx.createOscillator()
      const gain = ctx.createGain()
      osc.type = 'sine'
      osc.frequency.value = freq
      gain.gain.value = [0.42, 0.22, 0.12][i]
      osc.connect(gain); gain.connect(master); osc.start()
      oscillatorsRef.current.push(osc)
    })
    setMusicOn(true)
  }

  const startQuizOver = () => { setQuizStep(0); setAnswers([]); setQuizDone(false) }
  const answerQuiz = (answer) => {
    const next = [...answers, answer]
    setAnswers(next)
    if (quizStep === quiz.length - 1) setQuizDone(true)
    else setQuizStep(v => v + 1)
  }
  const result = answers.length ? quizResults[answers.reduce((sum, a) => sum + a, 0) % quizResults.length] : quizResults[0]

  return <main>
    <div className="grain" aria-hidden="true" />
    <nav className="nav">
      <a className="wordmark" href="#top" onClick={() => setEntered(true)}>FALAK<span>.</span></a>
      <div className={`nav-links ${menuOpen ? 'nav-open' : ''}`}>
        {['The day', 'Coffee lab', 'Garden', 'Night drive', 'Finale'].map((item, i) =>
          <a key={item} href={['#birthday', '#coffee', '#garden', '#drive', '#finale'][i]} onClick={() => setMenuOpen(false)}>{item}</a>)}
      </div>
      <div className="nav-right">
        <button className="sound-toggle" onClick={toggleMusic} aria-label={musicOn ? 'Turn ambient sound off' : 'Turn ambient sound on'}>
          {musicOn ? <Volume2 size={15}/> : <VolumeX size={15}/>} <span>{musicOn ? 'SOUND ON' : 'SOUND OFF'}</span>
        </button>
        <button className="menu-toggle" onClick={() => setMenuOpen(v => !v)} aria-label="Toggle navigation">{menuOpen ? <X/> : <Menu/>}</button>
      </div>
    </nav>

    <section className={`hero ${entered ? 'hero-entered' : ''}`} id="top">
      <div className="hero-orb orb-one" /><div className="hero-orb orb-two" />
      <div className="hero-particles" aria-hidden="true">{Array.from({length: 24}, (_, i) => <i key={i} style={{'--i': i}} />)}</div>
      <div className="hero-steam" aria-hidden="true"><i/><i/><i/></div>
      <div className="hero-content">
        <motion.div initial={{opacity:0, y:12}} animate={{opacity:1,y:0}} transition={{duration:1}} className="hero-kicker">A LIMITED BIRTHDAY EDITION <span>·</span> 25.11.26</motion.div>
        <AnimatePresence mode="wait">
          {!entered ? <motion.div key="intro" initial={{opacity:0}} animate={{opacity:1}} exit={{opacity:0,y:-20}} transition={{duration:.6}}>
            <p className="hero-pretitle">Ordinary was never the plan.</p>
            <h1 className="hero-title">Something different<br/><em>is brewing.</em></h1>
            <p className="hero-sub">A little universe, made for someone extraordinary.</p>
            <button className="pill-button" onClick={() => {setEntered(true); document.getElementById('birthday')?.scrollIntoView({behavior:'smooth'})}}>
              ENTER THE EXPERIENCE <ArrowUpRight size={16}/>
            </button>
          </motion.div> : <motion.div key="reveal" initial={{opacity:0, scale:.94}} animate={{opacity:1,scale:1}} transition={{duration:1}}>
            <p className="hero-pretitle">THE JAVAPHILE COLLECTION</p>
            <h1 className="hero-title hero-name">FALAK<span>.</span></h1>
            <p className="hero-sub">Allergic to the ordinary.</p>
            <a className="text-link" href="#birthday">DISCOVER THE COLLECTION <ArrowDown size={14}/></a>
          </motion.div>}
        </AnimatePresence>
      </div>
      <div className="hero-bottom"><span>EST. 25 NOVEMBER 2008</span><span>SCROLL TO EXPLORE ↓</span><span>NO. 001 / 026</span></div>
    </section>

    <section className="birthday section-pad" id="birthday">
      <div className="birthday-image">
        <div className="image-caption"><span>CHAPTER 01</span><span>THE DAY IS YOURS</span></div>
        <div className="bloom-mark"><Flower2 size={46} strokeWidth={1}/></div>
        <div className="birthday-image-copy">A new orbit.<br/><em>A new chapter.</em></div>
      </div>
      <div className="birthday-copy">
        <Eyebrow>CHAPTER 02 / HER DAY</Eyebrow>
        <p className="date-overline">25 NOVEMBER 2026</p>
        <h2>Happy birthday,<br/><em>Falak.</em></h2>
        <p className="lead">Another year of being wonderfully, unapologetically you.</p>
        <p className="body-copy">A little more experience, a few new stories, countless cups of coffee — and the same unmistakable way of making ordinary things feel a little less ordinary.</p>
        <div className="birthday-stamp"><span>25</span><small>NOV<br/>2026</small></div>
      </div>
    </section>

    <section className="coffee-section section-pad" id="coffee">
      <SectionHead index="03" eyebrow="THE JAVAPHILE COFFEE LAB" title={<>The daily dose<br/><em>of Falak.</em></>} subtitle="Two familiar favourites. A whole lot of personality."/>
      <div className="coffee-grid">
        <button className={`drink-card cranberry ${coffeeChoice === 'Cranbury' ? 'selected' : ''}`} onClick={() => {setCoffeeChoice('Cranbury');setCoffeeMessage(coffeeMessages[Math.floor(Math.random()*coffeeMessages.length)])}}>
          <div className="drink-top"><span>01 / THE PICK-ME-UP</span><ArrowUpRight size={17}/></div>
          <div className="cranberry-art"><div className="cranberry-cup"><span>F.</span></div><div className="berry berry-a"/><div className="berry berry-b"/><div className="berry berry-c"/></div>
          <div className="drink-info"><div><h3>Cranbury</h3><p>Her kind of choice.</p></div><span className="round-arrow">↗</span></div>
        </button>
        <button className={`drink-card latte ${coffeeChoice === 'Iced Latte' ? 'selected' : ''}`} onClick={() => {setCoffeeChoice('Iced Latte');setCoffeeMessage(coffeeMessages[Math.floor(Math.random()*coffeeMessages.length)])}}>
          <div className="drink-top"><span>02 / THE CLASSIC</span><ArrowUpRight size={17}/></div>
          <div className="latte-art">
            <div className="glass"><div className="ice ice-one"/><div className="ice ice-two"/><div className="latte-liquid"/></div>
            <div className="condensation c-one"/><div className="condensation c-two"/><div className="condensation c-three"/>
          </div>
          <div className="drink-info"><div><h3>Iced Latte</h3><p>Cold, calm, iconic.</p></div><span className="round-arrow">↗</span></div>
        </button>
      </div>
      <div className="brew-row">
        <div className="brew-copy"><span className="tiny-label">A LITTLE COFFEE-LOGY</span><p>{coffeeChoice ? <><strong>{coffeeChoice}</strong> selected. {coffeeMessage}</> : 'Pick your cup. Let the universe handle the rest.'}</p></div>
        <button className="outline-button" onClick={() => {setCoffeeChoice('Your mood');setCoffeeMessage(coffeeMessages[Math.floor(Math.random()*coffeeMessages.length)])}}>BREW MY MOOD <Coffee size={15}/></button>
      </div>
    </section>

    <section className="garden-section section-pad" id="garden">
      <div className="garden-backdrop"><div className="garden-glow"/></div>
      <SectionHead index="04" eyebrow="THE LAVENDER GARDEN" title={<>A place to<br/><em>just bloom.</em></>} subtitle="A small reminder that growing into yourself is its own kind of magic."/>
      <div className="garden-field">
        {wishes.map((wish, i) => <button className={`garden-flower flower-${i+1}`} key={wish} onClick={() => setGardenWish(wish)} aria-label={`Reveal flower wish ${i+1}`}>
          <span className="flower-petals"><i/><i/><i/><i/><i/><i/></span><span className="flower-center"/>
          <span className="flower-stem"/>
        </button>)}
        <div className="garden-note"><span>TO THE ONE WHO KEEPS GROWING</span><p>{gardenWish || 'Tap a bloom. Take a wish.'}</p></div>
      </div>
      <p className="garden-footnote">FLORAL NOTES · LAVENDER DREAMS · A HINT OF ROSELLE</p>
    </section>

    <section className={`drive-section section-pad ${driving ? 'is-driving' : ''}`} id="drive">
      <div className="drive-sky"><div className="moon"/><div className="city city-back"/><div className="city city-front"/></div>
      <div className="road"><div className="road-line"/></div>
      <div className="drive-content">
        <Eyebrow>CHAPTER 05 / THE MIDNIGHT DRIVE</Eyebrow>
        <span className="drive-label"><AudioLines size={13}/> AFTER HOURS / NO ROUTE PLANNED</span>
        <h2>No destination.<br/><em>Just good vibes.</em></h2>
        <p className="drive-quote">{driving ? driveLines[driveLine] : 'Some nights are made for open roads and unhurried thoughts.'}</p>
        <button className="pill-button" onClick={() => {setDriving(v => !v);setDriveLine(0)}}>{driving ? 'END THE DRIVE' : 'START THE DRIVE'} {driving ? <Pause size={15}/> : <Play size={15}/>}</button>
        <span className="drive-disclaimer">A SIMULATED MOMENT · NOT A REAL-WORLD JOURNEY</span>
      </div>
      <div className="dashboard"><span>00:25</span><span>FM · GOOD ENERGY</span><span>∞ KM / HR</span></div>
    </section>

    <section className="pizza-section section-pad" id="pizza">
      <div className="pizza-visual"><div className="pizza-glow"/><div className="pizza-dish"><div className="pizza-base">{Array.from({length:8},(_,i)=><i key={i} style={{'--n':i}}/>)}</div></div><span className="pizza-side-note">EXTRA CHEESE<br/>IS NON-NEGOTIABLE</span></div>
      <div className="pizza-copy">
        <Eyebrow>CHAPTER 06 / PIZZA INTERMISSION</Eyebrow>
        <h2>Important<br/><em>birthday business.</em></h2>
        <p className="lead">How much pepperoni pizza is too much?</p>
        <div className="pizza-options">
          {['One pizza is never enough.','Extra cheese. Always.','Who counts the slices anyway?'].map((v,i)=><button key={v} className={pizzaChoice===v?'active':''} onClick={()=>{setPizzaChoice(v);setPizzaReply(['A person of excellent priorities. The answer is: order another.','A flawless decision. Cheese deserves its own spotlight.','Exactly. Numbers are for spreadsheets, not pizza nights.'][i])}}><span>0{i+1}</span>{v}<ArrowUpRight size={15}/></button>)}
        </div>
        <AnimatePresence>{pizzaReply && <motion.p className="pizza-reply" initial={{opacity:0,y:8}} animate={{opacity:1,y:0}}>{pizzaReply}</motion.p>}</AnimatePresence>
      </div>
    </section>

    <section className="quiz-section section-pad" id="quiz">
      <SectionHead index="07" eyebrow="THE FALAK PERSONALITY TEST" title={<>A very serious<br/><em>investigation.</em></>} subtitle="Three questions. Absolutely no scientific validity. Immaculate vibes."/>
      <div className="quiz-panel">
        <div className="quiz-progress"><span>THE FALAK INDEX</span><span>{quizDone ? '03 / 03' : `0${quizStep+1} / 03`}</span></div>
        <div className="progress-track"><i style={{width: `${quizDone?100:(quizStep+1)/3*100}%`}}/></div>
        <AnimatePresence mode="wait">
          {!quizDone ? <motion.div key={quizStep} className="quiz-question" initial={{opacity:0,x:18}} animate={{opacity:1,x:0}} exit={{opacity:0,x:-18}} transition={{duration:.35}}>
            <span className="question-number">QUESTION 0{quizStep+1}</span>
            <h3>{quiz[quizStep].q}</h3>
            <div className="quiz-answers">{quiz[quizStep].a.map((a,i)=><button key={a} onClick={()=>answerQuiz(i)}><span>{String.fromCharCode(65+i)}</span>{a}<ArrowUpRight size={16}/></button>)}</div>
          </motion.div> : <motion.div key="result" className="quiz-result" initial={{opacity:0,scale:.96}} animate={{opacity:1,scale:1}}>
            <Sparkles size={25}/><span>OFFICIALLY CERTIFIED: FALAK.</span><h3>{result}</h3>
            <p>Powered by caffeine. Allergic to ordinary. Professionally interesting.</p>
            <button className="text-link" onClick={startQuizOver}><RotateCcw size={14}/> TAKE IT AGAIN</button>
          </motion.div>}
        </AnimatePresence>
      </div>
    </section>

    <section className="secret-section section-pad" id="secret">
      <Eyebrow>CHAPTER 08 / CLASSIFIED</Eyebrow>
      <p className="secret-overline">THERE'S ONE MORE THING.</p>
      <h2>Not everything<br/>needs a <em>label.</em></h2>
      <button className="secret-button" onClick={()=>setSecretOpen(true)}>THIS IS NOT AN ORDINARY BUTTON <ArrowUpRight size={16}/></button>
      <AnimatePresence>{secretOpen && <motion.div className="secret-overlay" initial={{opacity:0}} animate={{opacity:1}} exit={{opacity:0}}>
        <motion.div className="secret-card" initial={{opacity:0,y:24,scale:.96}} animate={{opacity:1,y:0,scale:1}} exit={{opacity:0,y:20}}>
          <button className="close-secret" onClick={()=>setSecretOpen(false)} aria-label="Close surprise"><X/></button>
          <div className="secret-flower"><Flower2 size={76} strokeWidth={.8}/><Sparkles className="secret-spark" size={20}/></div>
          <span className="tiny-label">A NOTE FOR YOUR NEXT CHAPTER</span>
          <p>Some people don't have to do anything extraordinary to be memorable.</p>
          <p>They simply have their own way of making the world a little more interesting.</p>
          <p>Keep your curiosity alive. Keep exploring. Keep being yourself.</p>
          <p>May this year bring you beautiful memories, unexpected adventures and everything good that life has to offer.</p>
          <h3>Happy Birthday, Falak.</h3>
        </motion.div>
      </motion.div>}</AnimatePresence>
    </section>

    <footer className="finale section-pad" id="finale">
      <div className="finale-stars"><i/><i/><i/><i/><i/><i/><i/></div>
      <div className="cake" aria-label="Birthday cake illustration"><div className="candle"><i/></div><div className="cake-top"/><div className="cake-middle"/><div className="cake-bottom"/></div>
      <Eyebrow>CHAPTER 09 / THE FINAL CELEBRATION</Eyebrow>
      <h2>Stay uncommon.<br/>Stay curious.<br/><em>Stay extraordinary.</em></h2>
      <div className="final-rule"/>
      <p className="final-happy">HAPPY BIRTHDAY, FALAK<span>.</span></p>
      <label className="signature-label" htmlFor="signature">THE SIGN-OFF <span>· EDITABLE</span></label>
      <input id="signature" className="signature-input" value={signature} onChange={e=>setSignature(e.target.value)} aria-label="Edit birthday signature"/>
      <div className="footer-meta"><span>FALAK. JAVAPHILE COLLECTION</span><span>25 NOVEMBER 2026</span><span>MADE FOR THE UNORDINARY</span></div>
    </footer>
  </main>
}

export default App
