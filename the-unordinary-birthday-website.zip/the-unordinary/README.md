# THE UNORDINARY — A Birthday Edition

A premium, mobile-first birthday experience built with React, Vite, Framer Motion and custom CSS.

## Run locally

```bash
npm install
npm run dev
```

Open the local URL printed by Vite.

## Build for hosting

```bash
npm run build
```

Vite creates the production site in `dist/`.

## Deploy to Vercel

1. Create a GitHub repository and upload this project.
2. Import the repository at https://vercel.com/new
3. Framework preset: **Vite**
4. Build command: `npm run build`
5. Output directory: `dist`
6. Deploy, then share the generated HTTPS URL.

You can also drag the `dist` folder into Netlify Drop after running the build.

## Personalization before sharing

- The signature is currently **Kaiff's** in the closing note and footer.
- The letter is intentionally warm and subtle, without a love confession or expectation.
- The date shown is 24 · 11 · 26. Change it in `src/main.jsx` if needed.
- The flower section is roselle-inspired rather than claiming a specific favourite flower.
- Replace the social preview in `public/social-preview.svg` if you want a custom share-card image.

## Notes

- No backend, login, analytics, or form is required.
- The site does not autoplay music.
- Google Fonts are loaded online; the design has fallback fonts if they are unavailable.
- The site is static and can be hosted on Vercel, Netlify, or any static host.
