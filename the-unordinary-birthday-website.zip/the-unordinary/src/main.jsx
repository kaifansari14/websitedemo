import React, { useState } from "react";
import { createRoot } from "react-dom/client";
import { motion, AnimatePresence } from "framer-motion";
import { ArrowDown, ArrowUpRight, Coffee, Flower2, Moon, Sparkles, VolumeX, Volume2, X } from "lucide-react";
import "./styles.css";

const wishes = [
  "May your days be as comforting as your favourite cup.",
  "May life take you to places that make you forget to check the time.",
  "May you always find reasons to bloom, even in unexpected seasons.",
  "May the ordinary never get too comfortable around you."
];

function App() {
  const [entered, setEntered] = useState(false);
  const [coffeeMode, setCoffeeMode] = useState("espresso");
  const [wish, setWish] = useState(-1);
  const [driveOn, setDriveOn] = useState(false);
  const [lit, setLit] = useState(false);
  const [letterOpen, setLetterOpen] = useState(false);

  const scrollTo = (id) => document.getElementById(id)?.scrollIntoView({ behavior: "smooth" });

  return (
    <main>
      <div className="grain" aria-hidden="true" />
      <nav className="nav">
        <a className="wordmark" href="#top">U<span>.</span></a>
        <div className="nav-right">
          <span className="edition">A BIRTHDAY EDITION · 2026</span>
          <button className="nav-link" onClick={() => scrollTo("signature")}>THE SIGN-OFF <ArrowUpRight size={13}/></button>
        </div>
      </nav>

      <section className="hero" id="top">
        <div className="hero-orbit orbit-one" />
        <div className="hero-orbit orbit-two" />
        <div className="hero-content">
          <motion.p className="eyebrow" initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: .2 }}>A SMALL DEPARTURE FROM THE ORDINARY</motion.p>
          <motion.h1 initial={{ opacity: 0, y: 24 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: .9, delay: .3 }}>
            THE<br/><em>UNORDINARY.</em>
          </motion.h1>
          <motion.div className="hero-bottom" initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: .9 }}>
            <p>A birthday edition for<br/><span>someone wonderfully different.</span></p>
            <button className="round-button" onClick={() => setEntered(true)} aria-label="Enter the experience"><ArrowDown size={18}/></button>
          </motion.div>
          <motion.div className="hero-stamp" initial={{ opacity: 0, rotate: -12, scale: .8 }} animate={{ opacity: 1, rotate: 8, scale: 1 }} transition={{ delay: 1.1 }}>
            <span>ALLERGIC TO</span><strong>THE<br/>ORDINARY</strong><small>EST. TODAY</small>
          </motion.div>
        </div>
        <div className="hero-foot"><span>01 / AN INTRODUCTION</span><span>SCROLL TO EXPLORE ↓</span></div>
      </section>

      <AnimatePresence>
        {entered && <motion.div className="welcome-overlay" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
          <motion.div className="welcome-card" initial={{ y: 25, scale: .97 }} animate={{ y: 0, scale: 1 }}>
            <button className="close" onClick={() => setEntered(false)} aria-label="Close"><X size={18}/></button>
            <span className="eyebrow">YOU MADE IT</span>
            <h2>Well, hello<br/><em>birthday girl.</em></h2>
            <p>No grand speech. Just a little corner of the internet made with you in mind.</p>
            <button className="text-button" onClick={() => { setEntered(false); scrollTo("coffee"); }}>TAKE A LOOK <ArrowUpRight size={14}/></button>
          </motion.div>
        </motion.div>}
      </AnimatePresence>

      <section className="intro section-pad">
        <div className="section-index">02 <span>THE PERSONALITY</span></div>
        <div className="intro-grid">
          <div>
            <p className="eyebrow">A NOTE ON THE SUBJECT</p>
            <h2>Some people<br/>just don't <em>do ordinary.</em></h2>
          </div>
          <div className="intro-copy">
            <p className="big-copy">A little caffeine. A little curiosity. A taste for the long way home.</p>
            <p>This isn't a list of reasons or a dramatic declaration. It's simply a birthday page inspired by the little things that make you, you.</p>
            <div className="bio-tag">“ ALLERGIC TO THE ORDINARY. ”</div>
          </div>
        </div>
      </section>

      <section className="coffee-section section-pad" id="coffee">
        <div className="section-index">03 <span>THE JAVAPHILE CHAPTER</span></div>
        <div className="coffee-layout">
          <div className="coffee-copy">
            <p className="eyebrow">A VERY IMPORTANT SUBJECT</p>
            <h2>First, we<br/>need <em>coffee.</em></h2>
            <p className="body-copy">Because some conversations deserve a good cup, and some days need a refill before they can even begin.</p>
            <div className="coffee-switch" role="group" aria-label="Choose coffee mood">
              <button className={coffeeMode === "espresso" ? "active" : ""} onClick={() => setCoffeeMode("espresso")}>ESPRESSO MOOD</button>
              <button className={coffeeMode === "iced" ? "active" : ""} onClick={() => setCoffeeMode("iced")}>ICED MOOD</button>
            </div>
            <p className="micro-note">{coffeeMode === "espresso" ? "Deep, bold, and not here to waste time." : "Cool, unbothered, and best enjoyed slowly."}</p>
          </div>
          <motion.div className={`coffee-art ${coffeeMode}`} key={coffeeMode} initial={{ opacity: 0, y: 20, rotate: 2 }} animate={{ opacity: 1, y: 0, rotate: 0 }}>
            <div className="coffee-glow"/>
            <div className="coffee-label">THE DAILY<br/><i>UNORDINARY</i></div>
            {coffeeMode === "espresso" ? <div className="espresso-cup"><div className="espresso-liquid"/><div className="cup-handle"/></div> : <div className="iced-glass"><div className="ice ice-a"/><div className="ice ice-b"/><div className="iced-liquid"/></div>}
            <div className="coffee-shadow"/>
            <span className="coffee-caption">{coffeeMode === "espresso" ? "01 / THE CLASSIC" : "02 / THE COOL ONE"}</span>
          </motion.div>
        </div>
      </section>

      <section className="garden-section section-pad">
        <div className="section-index">04 <span>IN BLOOM</span></div>
        <div className="garden-head">
          <p className="eyebrow">A LITTLE BOTANICAL DETOUR</p>
          <h2>For the days<br/>you <em>need to bloom.</em></h2>
          <p className="body-copy">Tap a bloom. There's a small wish tucked inside each one.</p>
        </div>
        <div className="flower-garden">
          {[0,1,2,3].map((n) => <button className={`flower flower-${n}`} key={n} onClick={() => setWish(n)} aria-label={`Open birthday wish ${n+1}`}>
            <span className="petals"><i/><i/><i/><i/><i/><i/></span><span className="flower-center"/><span className="flower-number">0{n+1}</span>
          </button>)}
        </div>
        <AnimatePresence mode="wait">
          {wish >= 0 && <motion.div className="wish-note" key={wish} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -8 }}>
            <span> A WISH FOR YOU </span><p>{wishes[wish]}</p><button onClick={() => setWish(-1)} aria-label="Close wish"><X size={14}/></button>
          </motion.div>}
        </AnimatePresence>
        <p className="garden-foot">LAVENDER HUES · ROSelle-INSPIRED BLOOMS · GOOD THINGS AHEAD</p>
      </section>

      <section className="drive-section">
        <div className="drive-image">
          <div className={`road ${driveOn ? "moving" : ""}`}><div className="road-line"/></div>
          <div className="city-lights"><i/><i/><i/><i/><i/><i/></div>
          <div className="drive-overlay"/>
          <div className="drive-content">
            <p className="eyebrow">05 / AFTER HOURS</p>
            <h2>The long way<br/><em>home.</em></h2>
            <p>Windows down. A good playlist. No rush to get anywhere.</p>
            <button className="outline-button" onClick={() => setDriveOn(!driveOn)}>{driveOn ? "PULL OVER FOR A SECOND" : "START THE NIGHT DRIVE"} <ArrowUpRight size={14}/></button>
            {driveOn && <motion.span className="drive-status" initial={{ opacity: 0 }} animate={{ opacity: 1 }}>NOW PLAYING: YOUR KIND OF FREEDOM</motion.span>}
          </div>
          <div className="drive-coordinate">17°23' N · 78°29' E<br/>SOMEWHERE AFTER SUNSET</div>
        </div>
      </section>

      <section className="birthday-section section-pad">
        <div className="section-index">06 <span>THE OCCASION</span></div>
        <div className="birthday-content">
          <p className="eyebrow">TODAY DESERVES A LITTLE EXTRA</p>
          <h2>Here's to another<br/>beautiful <em>orbit.</em></h2>
          <div className="cake-wrap">
            <div className="cake-glow"/>
            <div className="candle" onClick={() => setLit(!lit)} role="button" tabIndex="0" onKeyDown={(e) => e.key === "Enter" && setLit(!lit)} aria-label="Toggle candle">
              <span className={`flame ${lit ? "flame-out" : ""}`}/>
              <span className="wick"/>
            </div>
            <div className="cake-top"/><div className="cake-body"><span/><span/><span/></div><div className="cake-plate"/>
          </div>
          <p className="candle-hint">{lit ? "A wish has been made. Keep it close." : "TAP THE CANDLE TO MAKE A WISH"}</p>
          <p className="birthday-message">May your coffee stay strong, your playlists stay perfect, your drives run long, and life keep finding new ways to surprise you.</p>
          <div className="happy-birthday">HAPPY BIRTHDAY <span>✳</span></div>
        </div>
      </section>

      <section className="letter-section section-pad">
        <div className="section-index">07 <span>A FEW WORDS</span></div>
        <div className="letter-card">
          <div className="letter-top"><span> A NOTE, WITHOUT THE DRAMA </span><span>24 · 11 · 26</span></div>
          <p className="letter-tease">Some things are better said<br/>simply, and <em>meant sincerely.</em></p>
          <button className="text-button" onClick={() => setLetterOpen(true)}>OPEN THE NOTE <ArrowUpRight size={14}/></button>
          <div className="letter-flower"><Flower2 size={72} strokeWidth={.7}/></div>
        </div>
      </section>

      <AnimatePresence>
        {letterOpen && <motion.div className="letter-overlay" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
          <motion.div className="letter-modal" initial={{ y: 24, opacity: 0 }} animate={{ y: 0, opacity: 1 }}>
            <button className="close" onClick={() => setLetterOpen(false)} aria-label="Close letter"><X size={18}/></button>
            <span className="eyebrow">A BIRTHDAY NOTE</span>
            <h2>To you, <em>on your day.</em></h2>
            <p>Happy Birthday. I hope this next chapter brings you the kind of happiness that feels effortless, the kind of people who make life lighter, and plenty of little moments worth remembering.</p>
            <p>Keep being curious, keep choosing the scenic route, and never lose the part of you that refuses to settle for ordinary.</p>
            <p className="letter-last">Wishing you nothing but good things, today and always.</p>
            <div className="modal-sign">— Kaiff's</div>
          </motion.div>
        </motion.div>}
      </AnimatePresence>

      <footer className="footer section-pad" id="signature">
        <div className="footer-rule"/>
        <p className="eyebrow">MADE WITH INTENTION, NOT EXPECTATION</p>
        <h2>Stay <em>unordinary.</em></h2>
        <div className="footer-bottom"><span>THE UNORDINARY · BIRTHDAY EDITION 2026</span><span>CONCEIVED & CREATED BY <strong>KAIFF'S.</strong></span></div>
      </footer>
    </main>
  );
}

createRoot(document.getElementById("root")).render(<App />);